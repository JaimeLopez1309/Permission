package com.example.actividad;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.TelephonyCallback;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    public static final int REQUEST_CODE = 25;
    private Button btnCheckPermission;
    private Button btnRequestPermission;
    private TextView TvCamera;
    private TextView TvBiometric;
    private TextView TvExternalWS;
    private TextView TvReadExternalS;
    private TextView TvInternet;
    private TextView TvResponse;
    private TextView Versionndroid;
    private TextView TvConexion;
    private  int VersionSDK;
    private ProgressBar PbLevelBatery;
    private TextView TvlevelBatery;
    IntentFilter BatFilter;
    CameraManager cameramanager;
    String CameraID;
    private Button BtnON;
    private Button BtnOff;
    ConnectivityManager Conexion;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Metodo de enlade de objetos

        initObject();

        //enlace de botones a los metodos
        btnCheckPermission.setOnClickListener(this::voidcheckPermission);
        btnRequestPermission.setOnClickListener(this::voidRequestPermission);
    }
//verificacion de permisos
private void voidcheckPermission(View view) {
    // si hay permiso -->  ---> si no -->
    int statusCamera = ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.CAMERA);
    int statusWES = ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.WRITE_EXTERNAL_STORAGE);
    int statusRES = ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.READ_EXTERNAL_STORAGE);
    int statusInternet =ContextCompat.checkSelfPermission(getApplicationContext(),android.Manifest.permission.INTERNET);
    int statusBiometic = ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.USE_BIOMETRIC);
    TvCamera.setText("Status Camera: "+statusCamera);
    TvExternalWS.setText("Status WES: "+ statusWES);
    TvReadExternalS.setText("Status RES: "+ statusRES);
    TvInternet.setText("Status Internet: "+ statusInternet);
    TvBiometric.setText("Stustus Biometric: "+ statusBiometic);
    btnRequestPermission.setEnabled(true);
}
// implementacion del OnResume para version de androir
@Override    protected void onResume() {
    super.onResume();
    String versionSO = Build.VERSION.RELEASE;
    VersionSDK =Build.VERSION.SDK_INT;
    Versionndroid.setText("Version SO: " + versionSO + "/ SDK: " + VersionSDK);
}
// solicitud de permiso de camera
private void voidRequestPermission(View view) {
    if(ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
        ActivityCompat.requestPermissions(MainActivity.this, new String[]
                {android.Manifest.permission.CAMERA}, REQUEST_CODE);
    }
}
// gestion de respuesta de usuario respecto a la solicitud del permiso
@Override    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    TvResponse.setText(" "+ grantResults[0]);
    if(requestCode == REQUEST_CODE){
        if (grantResults[0] != PackageManager.PERMISSION_GRANTED){
        new AlertDialog.Builder(this)
                .setTitle("Permission Box")
                .setMessage("You denied the permission camera bitch")
                .setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", getPackageName(), null));
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);                            finish();
                    }
                }).setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                        finish();
                    }
                })
                .create().show();
        }
        else {
            Toast.makeText(this, "Usted no ha otorgado los permisos", Toast.LENGTH_SHORT).show();
        }
    }
    else {
        Toast.makeText(this, "Usted no ha otorgado los permisos", Toast.LENGTH_SHORT).show();
    }    }
    private void initObject(){
    btnCheckPermission = findViewById(R.id.BtnCheckPermission);
    btnRequestPermission = findViewById(R.id.BtnRequestPermission);
    btnRequestPermission.setEnabled(false);
    TvCamera = findViewById(R.id.TvCamera);
    TvBiometric = findViewById(R.id.TvDactilar);
    TvExternalWS =findViewById(R.id.TvEws);
    TvReadExternalS = findViewById(R.id.TvRs);
    TvInternet = findViewById(R.id.TvInternet);
    Versionndroid = findViewById(R.id.TvVersionAndroid);
    PbLevelBatery = findViewById(R.id.PbLevelBatery);
    TvlevelBatery = findViewById(R.id.TvLevelBatery);
    TvConexion = findViewById(R.id.TvConexion);
    BtnON = findViewById( R.id.BtnOn);
    BtnOff = findViewById( R.id.BtnOff);
}
}